/// id : "338"
/// uniq_id : "BkEWc"
/// owner_id : null
/// category_id : "123"
/// weight : "4"
/// vehicle_id : "323"
/// referral_code : "msid9"
/// executive_code : null
/// referral_price : null
/// username : ""
/// password : "4297f44b13955235245b2497399d7a93"
/// model : "2023"
/// rc_no : "gagahash"
/// vehicle_number : "hr11n6565"
/// vehicle_type : "Diesel"
/// first_name : "Mohan"
/// last_name : "K"
/// email : "msduhan111@gmail.com"
/// countryCode : null
/// contact_number : "9266809133"
/// gender : "male"
/// address : ""
/// lat : "26.8371073"
/// long : "75.8338985"
/// description : ""
/// city_id : "61"
/// bank_name : "sbi"
/// account_no : "121345494"
/// ifsc_code : "fafagag"
/// upi_id : "8319365289@YBL"
/// trn_id : null
/// commission : "10"
/// status : "1"
/// wallet_amount : "-32"
/// registration_fees : "21"
/// category_fees : "21"
/// payment_status : "paid"
/// adhar_no : "1234567879"
/// pan_no : "svhahaaha"
/// license_no : "gshagsga"
/// insurance : "5453434"
/// kyc : "complete"
/// running_order : "yes"
/// add_date : "2024-10-11 08:19:25"
/// update_date : "2025-07-30 12:43:41"
/// login_status : "offline"
/// online_time : "0000-00-00 00:00:00"
/// login_hours : ""
/// last_login_on : "2025-07-26 01:46:00"
/// read_status : "read"
/// user_status : "login"
/// category_name : "EV / 3 Wheeler"
/// file_name : null
/// weight_name : "500"
/// weight_type : "kgs"
/// vehicle_name : "3 Wheeler"
/// adhar_front_img : "67109f5c4d9b6-1729142563743.jpg"
/// adhar_back_img : "67109f5d286c4-1729142569984.jpg"
/// vehicle_img : null
/// driver_vehicle_img : "670bc024681b7-1728823328734.jpg"
/// pan_card_img : "67109f5de3e74-1729142575629.jpg"
/// insurance_img : "67109f5d80646-1729142609966.jpg"
/// rc_front_img : "67109f5ebdf41-1729142601737.jpg"
/// rc_back_img : "67109f5b5218a-1729142604867.jpg"
/// license_front_img : "67109f5dda6b9-1729142583367.jpg"
/// license_back_img : "67109f5e61378-1729142586795.jpg"
/// certificate_img : "67109f5e9fc6b-1729142615806.jpg"
/// vehicle_certificate_img : null
/// insurance_img_ext : "jpg"
/// vehicle_certificate_ext : ""
/// ratings : "4"
/// review : "15"
/// total_rating : "3.933333333333333"

class DriverInResponse {
  DriverInResponse({
      String? id, 
      String? uniqId, 
      dynamic ownerId, 
      String? categoryId, 
      String? weight, 
      String? vehicleId, 
      String? referralCode, 
      dynamic executiveCode, 
      dynamic referralPrice, 
      String? username, 
      String? password, 
      String? model, 
      String? rcNo, 
      String? vehicleNumber, 
      String? vehicleType, 
      String? firstName, 
      String? lastName, 
      String? email, 
      dynamic countryCode, 
      String? contactNumber, 
      String? gender, 
      String? address, 
      String? lat, 
      String? long, 
      String? description, 
      String? cityId, 
      String? bankName, 
      String? accountNo, 
      String? ifscCode, 
      String? upiId, 
      dynamic trnId, 
      String? commission, 
      String? status, 
      String? walletAmount, 
      String? registrationFees, 
      String? categoryFees, 
      String? paymentStatus, 
      String? adharNo, 
      String? panNo, 
      String? licenseNo, 
      String? insurance, 
      String? kyc, 
      String? runningOrder, 
      String? addDate, 
      String? updateDate, 
      String? loginStatus, 
      String? onlineTime, 
      String? loginHours, 
      String? lastLoginOn, 
      String? readStatus, 
      String? userStatus, 
      String? categoryName, 
      dynamic fileName, 
      String? weightName, 
      String? weightType, 
      String? vehicleName, 
      String? adharFrontImg, 
      String? adharBackImg, 
      dynamic vehicleImg, 
      String? driverVehicleImg, 
      String? panCardImg, 
      String? insuranceImg, 
      String? rcFrontImg, 
      String? rcBackImg, 
      String? licenseFrontImg, 
      String? licenseBackImg, 
      String? certificateImg, 
      dynamic vehicleCertificateImg, 
      String? insuranceImgExt, 
      String? vehicleCertificateExt, 
      String? ratings, 
      String? review, 
      String? totalRating,}){
    _id = id;
    _uniqId = uniqId;
    _ownerId = ownerId;
    _categoryId = categoryId;
    _weight = weight;
    _vehicleId = vehicleId;
    _referralCode = referralCode;
    _executiveCode = executiveCode;
    _referralPrice = referralPrice;
    _username = username;
    _password = password;
    _model = model;
    _rcNo = rcNo;
    _vehicleNumber = vehicleNumber;
    _vehicleType = vehicleType;
    _firstName = firstName;
    _lastName = lastName;
    _email = email;
    _countryCode = countryCode;
    _contactNumber = contactNumber;
    _gender = gender;
    _address = address;
    _lat = lat;
    _long = long;
    _description = description;
    _cityId = cityId;
    _bankName = bankName;
    _accountNo = accountNo;
    _ifscCode = ifscCode;
    _upiId = upiId;
    _trnId = trnId;
    _commission = commission;
    _status = status;
    _walletAmount = walletAmount;
    _registrationFees = registrationFees;
    _categoryFees = categoryFees;
    _paymentStatus = paymentStatus;
    _adharNo = adharNo;
    _panNo = panNo;
    _licenseNo = licenseNo;
    _insurance = insurance;
    _kyc = kyc;
    _runningOrder = runningOrder;
    _addDate = addDate;
    _updateDate = updateDate;
    _loginStatus = loginStatus;
    _onlineTime = onlineTime;
    _loginHours = loginHours;
    _lastLoginOn = lastLoginOn;
    _readStatus = readStatus;
    _userStatus = userStatus;
    _categoryName = categoryName;
    _fileName = fileName;
    _weightName = weightName;
    _weightType = weightType;
    _vehicleName = vehicleName;
    _adharFrontImg = adharFrontImg;
    _adharBackImg = adharBackImg;
    _vehicleImg = vehicleImg;
    _driverVehicleImg = driverVehicleImg;
    _panCardImg = panCardImg;
    _insuranceImg = insuranceImg;
    _rcFrontImg = rcFrontImg;
    _rcBackImg = rcBackImg;
    _licenseFrontImg = licenseFrontImg;
    _licenseBackImg = licenseBackImg;
    _certificateImg = certificateImg;
    _vehicleCertificateImg = vehicleCertificateImg;
    _insuranceImgExt = insuranceImgExt;
    _vehicleCertificateExt = vehicleCertificateExt;
    _ratings = ratings;
    _review = review;
    _totalRating = totalRating;
}

  DriverInResponse.fromJson(dynamic json) {
    _id = json['id'];
    _uniqId = json['uniq_id'];
    _ownerId = json['owner_id'];
    _categoryId = json['category_id'];
    _weight = json['weight'];
    _vehicleId = json['vehicle_id'];
    _referralCode = json['referral_code'];
    _executiveCode = json['executive_code'];
    _referralPrice = json['referral_price'];
    _username = json['username'];
    _password = json['password'];
    _model = json['model'];
    _rcNo = json['rc_no'];
    _vehicleNumber = json['vehicle_number'];
    _vehicleType = json['vehicle_type'];
    _firstName = json['first_name'];
    _lastName = json['last_name'];
    _email = json['email'];
    _countryCode = json['countryCode'];
    _contactNumber = json['contact_number'];
    _gender = json['gender'];
    _address = json['address'];
    _lat = json['lat'];
    _long = json['long'];
    _description = json['description'];
    _cityId = json['city_id'];
    _bankName = json['bank_name'];
    _accountNo = json['account_no'];
    _ifscCode = json['ifsc_code'];
    _upiId = json['upi_id'];
    _trnId = json['trn_id'];
    _commission = json['commission'];
    _status = json['status'];
    _walletAmount = json['wallet_amount'];
    _registrationFees = json['registration_fees'];
    _categoryFees = json['category_fees'];
    _paymentStatus = json['payment_status'];
    _adharNo = json['adhar_no'];
    _panNo = json['pan_no'];
    _licenseNo = json['license_no'];
    _insurance = json['insurance'];
    _kyc = json['kyc'];
    _runningOrder = json['running_order'];
    _addDate = json['add_date'];
    _updateDate = json['update_date'];
    _loginStatus = json['login_status'];
    _onlineTime = json['online_time'];
    _loginHours = json['login_hours'];
    _lastLoginOn = json['last_login_on'];
    _readStatus = json['read_status'];
    _userStatus = json['user_status'];
    _categoryName = json['category_name'];
    _fileName = json['file_name'];
    _weightName = json['weight_name'];
    _weightType = json['weight_type'];
    _vehicleName = json['vehicle_name'];
    _adharFrontImg = json['adhar_front_img'];
    _adharBackImg = json['adhar_back_img'];
    _vehicleImg = json['vehicle_img'];
    _driverVehicleImg = json['driver_vehicle_img'];
    _panCardImg = json['pan_card_img'];
    _insuranceImg = json['insurance_img'];
    _rcFrontImg = json['rc_front_img'];
    _rcBackImg = json['rc_back_img'];
    _licenseFrontImg = json['license_front_img'];
    _licenseBackImg = json['license_back_img'];
    _certificateImg = json['certificate_img'];
    _vehicleCertificateImg = json['vehicle_certificate_img'];
    _insuranceImgExt = json['insurance_img_ext'];
    _vehicleCertificateExt = json['vehicle_certificate_ext'];
    _ratings = json['ratings'];
    _review = json['review'];
    _totalRating = json['total_rating'];
  }
  String? _id;
  String? _uniqId;
  dynamic _ownerId;
  String? _categoryId;
  String? _weight;
  String? _vehicleId;
  String? _referralCode;
  dynamic _executiveCode;
  dynamic _referralPrice;
  String? _username;
  String? _password;
  String? _model;
  String? _rcNo;
  String? _vehicleNumber;
  String? _vehicleType;
  String? _firstName;
  String? _lastName;
  String? _email;
  dynamic _countryCode;
  String? _contactNumber;
  String? _gender;
  String? _address;
  String? _lat;
  String? _long;
  String? _description;
  String? _cityId;
  String? _bankName;
  String? _accountNo;
  String? _ifscCode;
  String? _upiId;
  dynamic _trnId;
  String? _commission;
  String? _status;
  String? _walletAmount;
  String? _registrationFees;
  String? _categoryFees;
  String? _paymentStatus;
  String? _adharNo;
  String? _panNo;
  String? _licenseNo;
  String? _insurance;
  String? _kyc;
  String? _runningOrder;
  String? _addDate;
  String? _updateDate;
  String? _loginStatus;
  String? _onlineTime;
  String? _loginHours;
  String? _lastLoginOn;
  String? _readStatus;
  String? _userStatus;
  String? _categoryName;
  dynamic _fileName;
  String? _weightName;
  String? _weightType;
  String? _vehicleName;
  String? _adharFrontImg;
  String? _adharBackImg;
  dynamic _vehicleImg;
  String? _driverVehicleImg;
  String? _panCardImg;
  String? _insuranceImg;
  String? _rcFrontImg;
  String? _rcBackImg;
  String? _licenseFrontImg;
  String? _licenseBackImg;
  String? _certificateImg;
  dynamic _vehicleCertificateImg;
  String? _insuranceImgExt;
  String? _vehicleCertificateExt;
  String? _ratings;
  String? _review;
  String? _totalRating;
DriverInResponse copyWith({  String? id,
  String? uniqId,
  dynamic ownerId,
  String? categoryId,
  String? weight,
  String? vehicleId,
  String? referralCode,
  dynamic executiveCode,
  dynamic referralPrice,
  String? username,
  String? password,
  String? model,
  String? rcNo,
  String? vehicleNumber,
  String? vehicleType,
  String? firstName,
  String? lastName,
  String? email,
  dynamic countryCode,
  String? contactNumber,
  String? gender,
  String? address,
  String? lat,
  String? long,
  String? description,
  String? cityId,
  String? bankName,
  String? accountNo,
  String? ifscCode,
  String? upiId,
  dynamic trnId,
  String? commission,
  String? status,
  String? walletAmount,
  String? registrationFees,
  String? categoryFees,
  String? paymentStatus,
  String? adharNo,
  String? panNo,
  String? licenseNo,
  String? insurance,
  String? kyc,
  String? runningOrder,
  String? addDate,
  String? updateDate,
  String? loginStatus,
  String? onlineTime,
  String? loginHours,
  String? lastLoginOn,
  String? readStatus,
  String? userStatus,
  String? categoryName,
  dynamic fileName,
  String? weightName,
  String? weightType,
  String? vehicleName,
  String? adharFrontImg,
  String? adharBackImg,
  dynamic vehicleImg,
  String? driverVehicleImg,
  String? panCardImg,
  String? insuranceImg,
  String? rcFrontImg,
  String? rcBackImg,
  String? licenseFrontImg,
  String? licenseBackImg,
  String? certificateImg,
  dynamic vehicleCertificateImg,
  String? insuranceImgExt,
  String? vehicleCertificateExt,
  String? ratings,
  String? review,
  String? totalRating,
}) => DriverInResponse(  id: id ?? _id,
  uniqId: uniqId ?? _uniqId,
  ownerId: ownerId ?? _ownerId,
  categoryId: categoryId ?? _categoryId,
  weight: weight ?? _weight,
  vehicleId: vehicleId ?? _vehicleId,
  referralCode: referralCode ?? _referralCode,
  executiveCode: executiveCode ?? _executiveCode,
  referralPrice: referralPrice ?? _referralPrice,
  username: username ?? _username,
  password: password ?? _password,
  model: model ?? _model,
  rcNo: rcNo ?? _rcNo,
  vehicleNumber: vehicleNumber ?? _vehicleNumber,
  vehicleType: vehicleType ?? _vehicleType,
  firstName: firstName ?? _firstName,
  lastName: lastName ?? _lastName,
  email: email ?? _email,
  countryCode: countryCode ?? _countryCode,
  contactNumber: contactNumber ?? _contactNumber,
  gender: gender ?? _gender,
  address: address ?? _address,
  lat: lat ?? _lat,
  long: long ?? _long,
  description: description ?? _description,
  cityId: cityId ?? _cityId,
  bankName: bankName ?? _bankName,
  accountNo: accountNo ?? _accountNo,
  ifscCode: ifscCode ?? _ifscCode,
  upiId: upiId ?? _upiId,
  trnId: trnId ?? _trnId,
  commission: commission ?? _commission,
  status: status ?? _status,
  walletAmount: walletAmount ?? _walletAmount,
  registrationFees: registrationFees ?? _registrationFees,
  categoryFees: categoryFees ?? _categoryFees,
  paymentStatus: paymentStatus ?? _paymentStatus,
  adharNo: adharNo ?? _adharNo,
  panNo: panNo ?? _panNo,
  licenseNo: licenseNo ?? _licenseNo,
  insurance: insurance ?? _insurance,
  kyc: kyc ?? _kyc,
  runningOrder: runningOrder ?? _runningOrder,
  addDate: addDate ?? _addDate,
  updateDate: updateDate ?? _updateDate,
  loginStatus: loginStatus ?? _loginStatus,
  onlineTime: onlineTime ?? _onlineTime,
  loginHours: loginHours ?? _loginHours,
  lastLoginOn: lastLoginOn ?? _lastLoginOn,
  readStatus: readStatus ?? _readStatus,
  userStatus: userStatus ?? _userStatus,
  categoryName: categoryName ?? _categoryName,
  fileName: fileName ?? _fileName,
  weightName: weightName ?? _weightName,
  weightType: weightType ?? _weightType,
  vehicleName: vehicleName ?? _vehicleName,
  adharFrontImg: adharFrontImg ?? _adharFrontImg,
  adharBackImg: adharBackImg ?? _adharBackImg,
  vehicleImg: vehicleImg ?? _vehicleImg,
  driverVehicleImg: driverVehicleImg ?? _driverVehicleImg,
  panCardImg: panCardImg ?? _panCardImg,
  insuranceImg: insuranceImg ?? _insuranceImg,
  rcFrontImg: rcFrontImg ?? _rcFrontImg,
  rcBackImg: rcBackImg ?? _rcBackImg,
  licenseFrontImg: licenseFrontImg ?? _licenseFrontImg,
  licenseBackImg: licenseBackImg ?? _licenseBackImg,
  certificateImg: certificateImg ?? _certificateImg,
  vehicleCertificateImg: vehicleCertificateImg ?? _vehicleCertificateImg,
  insuranceImgExt: insuranceImgExt ?? _insuranceImgExt,
  vehicleCertificateExt: vehicleCertificateExt ?? _vehicleCertificateExt,
  ratings: ratings ?? _ratings,
  review: review ?? _review,
  totalRating: totalRating ?? _totalRating,
);
  String? get id => _id;
  String? get uniqId => _uniqId;
  dynamic get ownerId => _ownerId;
  String? get categoryId => _categoryId;
  String? get weight => _weight;
  String? get vehicleId => _vehicleId;
  String? get referralCode => _referralCode;
  dynamic get executiveCode => _executiveCode;
  dynamic get referralPrice => _referralPrice;
  String? get username => _username;
  String? get password => _password;
  String? get model => _model;
  String? get rcNo => _rcNo;
  String? get vehicleNumber => _vehicleNumber;
  String? get vehicleType => _vehicleType;
  String? get firstName => _firstName;
  String? get lastName => _lastName;
  String? get email => _email;
  dynamic get countryCode => _countryCode;
  String? get contactNumber => _contactNumber;
  String? get gender => _gender;
  String? get address => _address;
  String? get lat => _lat;
  String? get long => _long;
  String? get description => _description;
  String? get cityId => _cityId;
  String? get bankName => _bankName;
  String? get accountNo => _accountNo;
  String? get ifscCode => _ifscCode;
  String? get upiId => _upiId;
  dynamic get trnId => _trnId;
  String? get commission => _commission;
  String? get status => _status;
  String? get walletAmount => _walletAmount;
  String? get registrationFees => _registrationFees;
  String? get categoryFees => _categoryFees;
  String? get paymentStatus => _paymentStatus;
  String? get adharNo => _adharNo;
  String? get panNo => _panNo;
  String? get licenseNo => _licenseNo;
  String? get insurance => _insurance;
  String? get kyc => _kyc;
  String? get runningOrder => _runningOrder;
  String? get addDate => _addDate;
  String? get updateDate => _updateDate;
  String? get loginStatus => _loginStatus;
  String? get onlineTime => _onlineTime;
  String? get loginHours => _loginHours;
  String? get lastLoginOn => _lastLoginOn;
  String? get readStatus => _readStatus;
  String? get userStatus => _userStatus;
  String? get categoryName => _categoryName;
  dynamic get fileName => _fileName;
  String? get weightName => _weightName;
  String? get weightType => _weightType;
  String? get vehicleName => _vehicleName;
  String? get adharFrontImg => _adharFrontImg;
  String? get adharBackImg => _adharBackImg;
  dynamic get vehicleImg => _vehicleImg;
  String? get driverVehicleImg => _driverVehicleImg;
  String? get panCardImg => _panCardImg;
  String? get insuranceImg => _insuranceImg;
  String? get rcFrontImg => _rcFrontImg;
  String? get rcBackImg => _rcBackImg;
  String? get licenseFrontImg => _licenseFrontImg;
  String? get licenseBackImg => _licenseBackImg;
  String? get certificateImg => _certificateImg;
  dynamic get vehicleCertificateImg => _vehicleCertificateImg;
  String? get insuranceImgExt => _insuranceImgExt;
  String? get vehicleCertificateExt => _vehicleCertificateExt;
  String? get ratings => _ratings;
  String? get review => _review;
  String? get totalRating => _totalRating;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['uniq_id'] = _uniqId;
    map['owner_id'] = _ownerId;
    map['category_id'] = _categoryId;
    map['weight'] = _weight;
    map['vehicle_id'] = _vehicleId;
    map['referral_code'] = _referralCode;
    map['executive_code'] = _executiveCode;
    map['referral_price'] = _referralPrice;
    map['username'] = _username;
    map['password'] = _password;
    map['model'] = _model;
    map['rc_no'] = _rcNo;
    map['vehicle_number'] = _vehicleNumber;
    map['vehicle_type'] = _vehicleType;
    map['first_name'] = _firstName;
    map['last_name'] = _lastName;
    map['email'] = _email;
    map['countryCode'] = _countryCode;
    map['contact_number'] = _contactNumber;
    map['gender'] = _gender;
    map['address'] = _address;
    map['lat'] = _lat;
    map['long'] = _long;
    map['description'] = _description;
    map['city_id'] = _cityId;
    map['bank_name'] = _bankName;
    map['account_no'] = _accountNo;
    map['ifsc_code'] = _ifscCode;
    map['upi_id'] = _upiId;
    map['trn_id'] = _trnId;
    map['commission'] = _commission;
    map['status'] = _status;
    map['wallet_amount'] = _walletAmount;
    map['registration_fees'] = _registrationFees;
    map['category_fees'] = _categoryFees;
    map['payment_status'] = _paymentStatus;
    map['adhar_no'] = _adharNo;
    map['pan_no'] = _panNo;
    map['license_no'] = _licenseNo;
    map['insurance'] = _insurance;
    map['kyc'] = _kyc;
    map['running_order'] = _runningOrder;
    map['add_date'] = _addDate;
    map['update_date'] = _updateDate;
    map['login_status'] = _loginStatus;
    map['online_time'] = _onlineTime;
    map['login_hours'] = _loginHours;
    map['last_login_on'] = _lastLoginOn;
    map['read_status'] = _readStatus;
    map['user_status'] = _userStatus;
    map['category_name'] = _categoryName;
    map['file_name'] = _fileName;
    map['weight_name'] = _weightName;
    map['weight_type'] = _weightType;
    map['vehicle_name'] = _vehicleName;
    map['adhar_front_img'] = _adharFrontImg;
    map['adhar_back_img'] = _adharBackImg;
    map['vehicle_img'] = _vehicleImg;
    map['driver_vehicle_img'] = _driverVehicleImg;
    map['pan_card_img'] = _panCardImg;
    map['insurance_img'] = _insuranceImg;
    map['rc_front_img'] = _rcFrontImg;
    map['rc_back_img'] = _rcBackImg;
    map['license_front_img'] = _licenseFrontImg;
    map['license_back_img'] = _licenseBackImg;
    map['certificate_img'] = _certificateImg;
    map['vehicle_certificate_img'] = _vehicleCertificateImg;
    map['insurance_img_ext'] = _insuranceImgExt;
    map['vehicle_certificate_ext'] = _vehicleCertificateExt;
    map['ratings'] = _ratings;
    map['review'] = _review;
    map['total_rating'] = _totalRating;
    return map;
  }

}