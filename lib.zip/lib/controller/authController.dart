import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';


import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:taxi_driver/common/color_extension.dart';
import 'package:taxi_driver/model/booking_details_response.dart';
import 'package:taxi_driver/model/booking_list_response.dart';
import 'package:taxi_driver/model/booking_notification_response.dart';
import 'package:taxi_driver/model/driver_in_response.dart';
import 'package:taxi_driver/view/home/home_view.dart';
import 'package:taxi_driver/view/login/mobile_number_view.dart';
import 'package:url_launcher/url_launcher.dart';


import '../api/api_checker.dart';

import '../common/appContants.dart';
import '../common/custom_snackbar.dart';
import '../common/driver_notification_service.dart';
import '../common/globs.dart';
import '../model/category_type_response.dart' hide Data;
import '../model/running_order_response.dart';
import '../model/subCategoryVehicle.dart' hide Data;
import '../model/vehicle_data.dart' hide Data;
import '../model/wallet_response.dart';
import '../repo/auth_repo.dart';
import '../view/home/tip_request_view.dart';



class AuthController extends GetxController implements GetxService
{

  AuthRepo authRepo;

  AuthController({required this.authRepo});
  bool isLoading = false;
  bool isBookingProcess = false;
  bool isShowDriver = false;
  bool hasShownSheet = false;
  File? _image;
  String _verificationCode = '';
  String walletAmount = "0";
  CategoryTypeResponse? categoryTypeResponse = CategoryTypeResponse();
  SubCategoryVehicle? subCategoryVehicle = SubCategoryVehicle();

  VehicleData? vehicleData = VehicleData();
  int? getIndex;
  List<String>banners = ["https://crossroadshelpline.com/_next/image?url=%2F_next%2Fstatic%2Fmedia%2FLifetime-Family-Plan-offer-slider.1c6725bf.webp&w=3840&q=75",
    "https://crossroadshelpline.com/_next/image?url=%2F_next%2Fstatic%2Fmedia%2FFree-Car-Care-Kit.46a9b3ee.webp&w=3840&q=75","https://crossroadshelpline.com/_next/image?url=%2F_next%2Fstatic%2Fmedia%2FTitanium-Family-Plan.d35e75e6.webp&w=3840&q=75","https://crossroadshelpline.com/_next/image?url=%2F_next%2Fstatic%2Fmedia%2FPlatinum-Family-Plan.2eb81b06.webp&w=3840&q=75"];
  int currentIndex = 0;
  bool isVehicle = false;
  String newBookingID = "";
  Timer? _locationUpdateTimer;
  String _email = '';
  String get verificationCode => _verificationCode;
  String get email => _email;

  File? get image =>_image;

  RxDouble lat = 0.0.obs;
  RxDouble lng = 0.0.obs;
  StreamSubscription<Position>? _positionStreamSubscription;

  @override
  void onInit() {
    super.onInit();
    _checkLocationPermission();

  }

  Timer? _bookingNotificationTimer;


  /// इसे हर 10 सेकंड में कॉल करेगा
  void startBookingNotificationPolling(BuildContext context) {
    _bookingNotificationTimer?.cancel();

    _bookingNotificationTimer = Timer.periodic(Duration(seconds: 10), (timer) {
      getBookingNotification(context);
    });
  }

  String checkLoginTime(int loginSeconds) {

    double hours = loginSeconds / 3600;

    if (hours > 12) {
      return "false";
    } else {
      return hours.toStringAsFixed(2); // hours ko 2 decimal tak string me
    }
  }


  void checkAndStartBookingNotification(BuildContext context) {
    startBookingNotificationPolling(context);

    // condition check: driverInResponse != null && runningOrder != "yes"
    // if (driverInResponse != null &&/* driverInResponse!.runningOrder.toString() != "yes" &&*/ runningOrderResponse!=null && runningOrderResponse!.orders==null) {
    //   print("isDriver Not Runing ");
    //   startBookingNotificationPolling(context);
    // } else {
    //   print("isDriver  Runing ");
    //   stopBookingNotificationPolling(); // "yes" आने पर बंद कर दो
    // }
  }

  void stopBookingNotificationPolling() {
    _bookingNotificationTimer?.cancel();
    _bookingNotificationTimer = null;

    print("Stopped polling.");
  }
  /// App बंद या Controller destroy हो तब टाइमर बंद करें
  @override
  void onClose() {
    _bookingNotificationTimer?.cancel();
    stopBookingNotificationPolling();
    _positionStreamSubscription?.cancel();
    super.onClose();
  }

  Future<void> _checkLocationPermission() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }

    _startLocationUpdates();
  }

  void _startLocationUpdates() {
    const LocationSettings locationSettings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 0, // 0 means smallest movement bhi track hoga
    );

    _positionStreamSubscription?.cancel(); // safety: pehle ka stream close karo

    _positionStreamSubscription = Geolocator.getPositionStream(
      locationSettings: locationSettings,
    ).listen((Position position) {
      print("📍 New Position: ${position.latitude}, ${position.longitude}");

      // Throttle - sirf har 3 second me API call
      if (_locationUpdateTimer == null || !_locationUpdateTimer!.isActive) {
        _updateDriverLocationOnServer(position.latitude, position.longitude);

        _locationUpdateTimer = Timer(const Duration(seconds: 3), () {
          // Timer khatam hone par next call allow hoga
          _updateDriverLocationOnServer(position.latitude, position.longitude);
        });
      }
    });
  }

  Future<void> _updateDriverLocationOnServer(
      double latitude, double longitude) async {
    try {
      print("🚀 Updating location with lat: $latitude, long: $longitude");

      await updateDriverLocation(
        lat: latitude.toString(),
        long: longitude.toString(),
      );

      print("✅ Location updated successfully");
    } catch (e) {
      print("❌ Error updating location: $e");
    }
  }

  void stopLocationUpdates() {
    _positionStreamSubscription?.cancel();
    _locationUpdateTimer?.cancel();
    print("🛑 Location updates stopped");
  }









  updateGetIndex(int index){
    getIndex = index;
    update();
  }
  void setCurrentIndex(int index, bool notify) {
    currentIndex = index;
    if(notify) {
      update();
    }
  }
  Future<void>loginFunction(String email,String password)
  async {

    isLoading = true;

    update();
    print(getUserDeviceID());
    String? token = "";

    if(Platform.isAndroid)
    {
      token =  await FirebaseMessaging.instance.getToken();
    }
    else
    {
      token = await FirebaseMessaging.instance.getAPNSToken();
    }



    Response response = await authRepo.login(
        token: token,
        phone: email, password:
    password);

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {

      if(response.body["status"].toString() == "false"){
        showCustomSnackBar(response.body["message"], getXSnackBar: false,isError: true);
      }
      else {
        showCustomSnackBar(
            response.body["message"], getXSnackBar: false, isError: false);
        // loginResponse = LoginResponse.fromJson(response.body);
        // _lResponse = LoginResponse.fromJson(response.body);
        authRepo.saveUserToken(response.body['token']);
        authRepo.saveUserName(response.body['name']);
        authRepo.saveUserEmail(response.body['email']);
        authRepo.saveUserPhone(response.body['contact_number']);
        // authRepo.saveUserPassword(password);
        authRepo.saveUserId(response.body['id'].toString());
        // if(response.body["success"]) {
        //   showCustomSnackBar(response.body["message"], getXSnackBar: false,isError: false);
        // }
        Get.offAll(HomeView());
      }
      _image = null;
    }
    else {


      // dynamic data = jsonDecode(response.body);

      ApiChecker.checkApi(response);




    }

    isLoading = false;
    update();



  }

  Future<void>incomeDriver()
  async {

    isLoading = true;

    update();
    print(getUserDeviceID());
    walletAmount = "0";


    Response response = await authRepo.incomeDriver(userID: getUserID());

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {

      if(response.body["amount"]!=null){
        walletAmount = (double.parse((response.body["amount"]??0).toString())).toStringAsFixed(0);
        update();
      }

    }
    else {


      // dynamic data = jsonDecode(response.body);

      ApiChecker.checkApi(response);




    }

    isLoading = false;
    update();



  }

  Future<void>updateDriverLocation({String? lat,String? long})
  async {

    isLoading = true;

    update();
    print(getUserDeviceID());


    Response response = await authRepo.updateDriverLocation(userID: getUserID(),long: long,lat: lat);

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {


     /// updateDriverLocation(lat:lat.toString(),long:long.toString());

    }
    else {


      ApiChecker.checkApi(response);


    }

    isLoading = false;
    update();




  }

  List<WalletResponse>walletResponseList = [];

  Future<void>changeLoginStatus({String? status,BuildContext? context})
  async {

    isLoading = true;

    update();
    print(getUserDeviceID());


    Response response = await authRepo.changeLoginStatus(userID: getUserID(),status: status,);

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {



      if(status == "online") {
        await DriverNotificationService.showOnlineNotification();
      }

         else {
          await DriverNotificationService.showOfflineNotification();
        }

      driverInfo(context!);
    }
    else {


      ApiChecker.checkApi(response);


    }

    isLoading = false;
    update();



  }


  String todayLoginTIme = "";
  Future<void>driverOnlineTIme()
  async {

    isLoading = true;

    update();
    print(getUserDeviceID());


    Response response = await authRepo.driverOnlineTIme(userID: getUserID());

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {



      if(response.body!=null){
        todayLoginTIme = response.body["online_time"].toString();
        update();
      }



    }
    else {


      ApiChecker.checkApi(response);


    }

    isLoading = false;
    update();



  }

  String totalLoginTIme = "";
  Future<void>driverOnlineTotalTIme()
  async {

    isLoading = true;

    update();
    print(getUserDeviceID());


    Response response = await authRepo.driverOnlineTotalTIme(userID: getUserID());

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {



      if(response.body!=null){

        totalLoginTIme = response.body["online_time"].toString();
        update();
      }



    }
    else {


      ApiChecker.checkApi(response);


    }

    isLoading = false;
    update();



  }

  Future<void>getWalletHistory()
  async {

    isLoading = true;

    update();
    print(getUserDeviceID());


    Response response = await authRepo.getWalletHistory(userID: getUserID());

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {

      for(int i=0;i<response.body.length; i++){
        walletResponseList.add(WalletResponse.fromJson(response.body[i]));
      }
    }
    else {


      ApiChecker.checkApi(response);


    }

    isLoading = false;
    update();



  }

  Future<void>saveFirebaseToken(String token)
  async {

    isLoading = true;

    update();
    print(getUserDeviceID());


    Response response = await authRepo.saveFirebaseToken(userID: token);

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {


    }
    else {


      ApiChecker.checkApi(response);


    }

    isLoading = false;
    update();



  }

  Future<void>bookingStatusChange({String? status,String? cus_id,String? orderID,String? amount,int? value})
  async {

    isLoading = true;
    Globs.showHUD();

    update();
    print(getUserDeviceID());


    Response response = await authRepo.bookingStatusChange(userID: getUserID(),status: status,cus_id: cus_id,orderID: orderID,amount: amount);

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {


      hasShownSheet = false;

      Get.offAll(HomeView());
      // if(value ==0) {
      //   Get.offAll(HomeView());
      // }


    }
    else {


      ApiChecker.checkApi(response);


    }

    isLoading = false;
    Globs.hideHUD();
    update();



  }

  Future<void>accpetBooking({String? cus_id,String? orderID,String? amount,int? value})
  async {

    isLoading = true;
    Globs.showHUD();

    update();
    print(getUserDeviceID());


    Response response = await authRepo.accpetBooking(userID: getUserID(),bookingId: orderID);

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {


      hasShownSheet = false;

      Get.offAll(HomeView());



    }
    else {
      ApiChecker.checkApi(response);

    }

    isLoading = false;
    Globs.hideHUD();
    update();



  }

  Future<void>orderPicked({String? cus_id,String? orderID,String? amount,int? value})
  async {

    isLoading = true;
    Globs.showHUD();

    update();
    print(getUserDeviceID());


    Response response = await authRepo.orderPicked(userID: getUserID(),bookingId: orderID);

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {
      hasShownSheet = false;

      Get.offAll(HomeView());



    }
    else {
      ApiChecker.checkApi(response);

    }

    isLoading = false;
    Globs.hideHUD();
    update();



  }

  Future<void>orderDelivered({String? cus_id,String? orderID,String? amount,int? value})
  async {

    isLoading = true;
    Globs.showHUD();

    update();
    print(getUserDeviceID());


    Response response = await authRepo.orderDelivered(userID: getUserID(),bookingId: orderID);

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {
      hasShownSheet = false;

      Get.offAll(HomeView());



    }
    else {
      ApiChecker.checkApi(response);

    }

    isLoading = false;
    Globs.hideHUD();
    update();



  }


  RunningOrderResponse? runningOrderResponse = RunningOrderResponse();

  Future<void>checkDriverBooking(BuildContext context)
  async {

    isLoading = true;
    Globs.showHUD();

    update();
    print(getUserDeviceID());


    Response response = await authRepo.checkDriverBooking(userID: getUserID());

  //  LoginResponse? loginResponse;


    if(response.statusCode==200 || response.statusCode ==400)
    {
      runningOrderResponse = null;


      runningOrderResponse = RunningOrderResponse.fromJson(response.body);


      if(response.body["status"] == false){
        checkAndStartBookingNotification(context);
      }
      else {
        checkAndShowBottomSheet(context);

      }


      update();



    }
    else {


      ApiChecker.checkApi(response);


    }

    isLoading = false;
    Globs.hideHUD();
    update();



  }

  Future<void>startTrip(String id,String status,BuildContext context,String cusId,String orderID,String amount)
  async {

    isLoading = true;
    Globs.showHUD();

    update();
    print(getUserDeviceID());


    Response response = await authRepo.startTrip(iD: id,type: status);

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {

      if(status.toLowerCase() == "no"){
        checkAndStartBookingNotification(context);

        bookingStatusChange(status: "close",cus_id: cusId,orderID: orderID,amount: amount, value: 1);
      }
      else {
        bookingStatusChange(status: "accept",cus_id: cusId,orderID: orderID,amount: amount, value: 1);
      }






      update();



    }
    else {


      ApiChecker.checkApi(response);


    }

    isLoading = false;
    Globs.hideHUD();
    update();



  }

  void checkAndShowBottomSheet(BuildContext context) {
    if (runningOrderResponse != null && runningOrderResponse!.orders != null && runningOrderResponse!.orders !.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showRunningDetailsSheet(runningOrderResponse!.orders![0], context);
      });
    } else if (notificationResponse.isNotEmpty) {

      print("length=>${notificationResponse.length}");

      update();
      stopBookingNotificationPolling();

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (context.mounted) {
          showRideDetailsSheet(notificationResponse[0], context);
        }
      });

    }
  }
  List<BookingNotificationResponse> notificationResponse = [];

  Future<void>getBookingNotification(BuildContext context)
  async {

    isLoading = true;

    update();
    print(getUserDeviceID());


    Response response = await authRepo.getBookingNotification(userID: getUserID());

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {


      notificationResponse = [];

      if(response.body["bookings"]!=null && response.body["bookings"].isNotEmpty){
        for(int i=0; i<response.body["bookings"].length; i++){
          notificationResponse.add(BookingNotificationResponse.fromJson(response.body["bookings"][i]));
        }

        checkAndShowBottomSheet(context);
        checkDriverBooking(context);
        stopBookingNotificationPolling();

      //  await  context.push( TipRequestView(bObj: BookingNotificationResponse.fromJson(response.body[0])) );
      }
      
    }
    else {


      ApiChecker.checkApi(response);


    }

    isLoading = false;
    update();



  }

  DriverInResponse? driverInResponse = DriverInResponse();

  Future<void>driverInfo(BuildContext context)
  async {

    isLoading = true;

    update();
    print(getUserDeviceID());
    driverInResponse = null;


    Response response = await authRepo.driverInfo(getUserID().toString());

  //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {

      driverInResponse = DriverInResponse.fromJson(response.body);

      if(driverInResponse!=null && driverInResponse!.loginHours!=null){

      }

      checkDriverBooking(context);


      update();



    }
    else {


      ApiChecker.checkApi(response);


    }

    isLoading = false;
    update();



  }




  bool getAllBookingLoading = false;

  List<BookingListResponse>bookingListResponse = [];

  Future<void>getAllBooking({String? status,String? limit,String? offset})
  async {

    getAllBookingLoading = true;

    update();
    print(getUserDeviceID());



    // vehicleData = null;
    Response response = await authRepo.getAllBooking(status: status,limit: limit,offset: offset,userID: getUserID());



    bookingListResponse = [];
    if(response.statusCode==200 || response.statusCode ==400)
    {

      isShowDriver = false;
      for(int i=0; i<response.body.length; i++){
        bookingListResponse.add( BookingListResponse.fromJson(response.body[i]));
      }



      // getAllBookingLoading = false;
      update();
    }
    else {


      // dynamic data = jsonDecode(response.body);

      ApiChecker.checkApi(response);




    }

    getAllBookingLoading = false;
    update();



  }

  bool isBookingDetails = false;
  BookingDetailsResponse? bookingDetailsResponse = BookingDetailsResponse();
  Future<void>getBookingDetails({String? bookingID,String? driverLat,String? driverLng})
  async {

    isBookingDetails = true;

    update();
    print(getUserDeviceID());
    bookingDetailsResponse = null;



    // vehicleData = null;
    Response response = await authRepo.getBookingDetails(bookingID: bookingID,userID: getUserID());




    if(response.statusCode==200 || response.statusCode ==400)
    {


      bookingDetailsResponse = BookingDetailsResponse.fromJson(response.body);

      if(driverLat!=null && driverLat!.isNotEmpty && driverLng!=null && driverLng!.isNotEmpty && bookingDetailsResponse!=null){



        print("driverLat!=>$driverLat!");
        print("driverLng!=>$driverLng!");



      }


      // getAllBookingLoading = false;
      update();
    }
    else {


      // dynamic data = jsonDecode(response.body);

      ApiChecker.checkApi(response);




    }

    isBookingDetails = false;
    update();



  }





  Future<void>updateImage(var image)async
  {
    _image = image;

    update();
  }


  Future<void> pickImageFromCamera() async {
    final picker = ImagePicker();

    // Pick image from the front camera
    final pickedFile = await picker.pickImage(
      source: ImageSource.camera,
      preferredCameraDevice: CameraDevice.front,

    );

    if (pickedFile != null) {
      _image = File(pickedFile.path);
    }

    update();
  }


  bool isLoggedIn() {
    return authRepo.isLoggedIn();
  }

  bool clearSharedData() {
    return authRepo.clearSharedData();
  }

  String? getUserID()
  {
    return authRepo.sharedPreferences.getString(AppContants.userID);
  }

  String? getUserDeviceID()
  {
    return authRepo.sharedPreferences.getString(AppContants.userDeviceID);
  }

  String? getUserPassword()
  {
    return authRepo.sharedPreferences.getString(AppContants.userPassword);
  }

  String? getUserName()
  {
    return authRepo.sharedPreferences.getString(AppContants.userName);
  }

  String? getUserEmail()
  {
    return authRepo.sharedPreferences.getString(AppContants.userEmail);
  }

  String? getUserPhone()
  {
    return authRepo.sharedPreferences.getString(AppContants.userPhone);
  }

  Future<void> logoutUser() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    // ✅ Clear all stored preferences
    await prefs.clear();

    // ✅ Optional: navigate to login or splash screen
    Get.offAll(MobileNumberView());
  }


  void showRideDetailsSheet(BookingNotificationResponse notificationResponse,BuildContext context) {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      isScrollControlled: true, // Allows the sheet to take up more space
      backgroundColor: Colors.transparent, // Makes the rounded corners visible
      builder: (context) => Container(
        padding: const EdgeInsets.only(top: 20), // Space for the drag handle
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        child: DraggableScrollableSheet(
          expand: false,
          shouldCloseOnMinExtent: false,
          initialChildSize: 0.5, // Initial height (40% of screen)
          minChildSize: 0.3, // Minimum height when dragged down
          maxChildSize: 0.7, // Maximum height when dragged up
          builder: (context, scrollController) {
            return  WillPopScope(
              onWillPop: () async {
                // ❌ back button से बंद नहीं होने देना
                return false;
              },
              child: SingleChildScrollView(
                controller: scrollController,
                child: _buildRideDetailsContent(notificationResponse,context),
              ),
            );
          },
        ),
      ),
    );
  }


  void showRunningDetailsSheet(Orders? notificationResponse,BuildContext context) {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      showDragHandle: false,

      isScrollControlled: true, // Allows the sheet to take up more space
      backgroundColor: Colors.transparent, // Makes the rounded corners visible
      builder: (context) => Container(
        padding: const EdgeInsets.only(top: 20), // Space for the drag handle
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        child: DraggableScrollableSheet(
          expand: false,
          shouldCloseOnMinExtent: false,

          initialChildSize: 0.5, // Initial height (40% of screen)
          minChildSize: 0.2, // Minimum height when dragged down
          maxChildSize: 0.7, // Maximum height when dragged up
          builder: (context, scrollController) {
            return WillPopScope(
              onWillPop: () async {
                // ❌ back button से बंद नहीं होने देना
                return false;
              },
              child: SingleChildScrollView(
                controller: scrollController,
                child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minHeight: MediaQuery.of(context).size.height * 0.3, // Match minChildSize
                    ),child: _buildRunningDetailsContent(notificationResponse!,context)),
              ),
            );
          },
        ),
      ),
    );
  }



// The content of your bottom sheet (your original Column widget with slight modifications)
  Widget _buildRideDetailsContent(BookingNotificationResponse bookingResponse,BuildContext context) {
    return Column(
      children: [
        // Drag handle indicator
        Container(
          width: 40,
          height: 5,
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(2.5),
          ),
        ),
        const SizedBox(height: 15),

        // Your original content with some padding adjustments
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
          child: Column(
            children: [

              Row(
                children: [
                  Expanded(
                    child: Text(
                      "${AppContants.rupessSystem} ${bookingResponse.totalAmount ?? ""}",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: TColor.secondaryText,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      "${calculateDistance(double.parse(bookingResponse.pickupLat??"0"),double.parse(bookingResponse.pickupLong??"0"),double.parse(bookingResponse.dropLat??"0"),double.parse(bookingResponse.dropLong??"0")).toStringAsFixed(2)}  KM",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: TColor.secondaryText,
                        fontSize: 18,
                      ),
                    ),
                  ),

                ],
              ),
              const SizedBox(height: 15),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Row(
                  children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: TColor.secondary,
                        borderRadius: BorderRadius.circular(10),
                      ),),
                    const SizedBox(width: 15),
                    Expanded(
                      child: Text(
                        "${bookingResponse.pickupAddress ?? ""}",
                        style: TextStyle(
                          color: TColor.primaryText,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Row(
                  children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(color: TColor.primary),
                    ),
                    const SizedBox(width: 15),
                    Expanded(
                      child: Text(
                        "${bookingResponse.dropAddress ?? ""}",
                        style: TextStyle(
                          color: TColor.primaryText,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 15),
              Row(
                children: [
                  InkWell(
                    onTap: () {
                     // Navigator.pop(context); // Close the bottom sheet
                      bookingStatusChange(
                        status: "cancel",
                        amount: bookingResponse.totalAmount,
                        orderID: bookingResponse.orderId,
                        cus_id:bookingResponse.cusId,
                        value: 0
                      );
                    },
                    child: Container(

                      margin: const EdgeInsets.only(left: 20),
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: TColor.red,
                        shape: BoxShape.circle,

                      ),
                      child: Icon(Icons.close,color: Colors.white,),
                    ),
                  ),
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context); // Close the bottom sheet
                        accpetBooking(

                          orderID: bookingResponse.id,
                          cus_id:bookingResponse.cusId,
                            value: 0
                        );
                      },
                      child: Container(
                        width: double.maxFinite,
                        margin: const EdgeInsets.symmetric(horizontal: 20),
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: TColor.primary,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Stack(
                          alignment: Alignment.centerRight,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "TAP TO ACCEPT",
                                  style: TextStyle(
                                    color: TColor.primaryTextW,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              height: 40,
                              width: 40,
                              decoration: BoxDecoration(
                                color: Colors.black12,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              alignment: Alignment.center,
                              child: Text(
                                "15",
                                style: TextStyle(
                                  color: TColor.primaryTextW,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 25),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRunningDetailsContent(Orders bookingResponse,BuildContext context) {
    return Column(
      children: [
        // Drag handle indicator
        Container(
          width: 40,
          height: 5,
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(2.5),
          ),
        ),
        const SizedBox(height: 15),

        // Your original content with some padding adjustments
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
          child: Column(
            children: [


              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Row(
                  children: [
                    const CircleAvatar(
                      radius: 30,
                      backgroundImage: NetworkImage('https://randomuser.me/api/portraits/men/1.jpg'),
                    ),
                    const SizedBox(width: 15),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${bookingResponse.senderName}',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        InkWell(
                          onTap: (){
                            AppContants.makePhoneCall(bookingResponse.senderContactNumber.toString());

                          },
                          child: Row(
                            children: [
                              Icon(Icons.call_outlined, color: Colors.blue, size: 16),
                              const SizedBox(width: 5),
                               Text('${bookingResponse.senderContactNumber}'),
                            ],
                          ),
                        ),
                      ],
                    ),

                  ],
                ),
              ),

              SizedBox(height: 10,),

              Row(
                children: [
                  Expanded(
                    child: Text(
                      "${AppContants.rupessSystem} ${bookingResponse.totalAmount ?? ""}",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: TColor.secondaryText,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      "${calculateDistance(double.parse(bookingResponse.pickupLat??"0"),double.parse(bookingResponse.pickupLong??"0"),double.parse(bookingResponse.dropLat??"0"),double.parse(bookingResponse.dropLong??"0")).toStringAsFixed(2)}  KM",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: TColor.secondaryText,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  /*Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset(
                            "assets/img/rate_tip.png",
                            width: 15,
                            height: 15,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            "5",
                            style: TextStyle(
                              color: TColor.secondaryText,
                              fontSize: 18,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),*/
                ],
              ),
              const SizedBox(height: 15),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.location_on_outlined,color: Colors.green,),
                    const SizedBox(width: 15),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "${bookingResponse.pickupAddress ?? ""}",
                            style: TextStyle(
                              color: TColor.primaryText,
                              fontSize: 15,
                            ),
                          ),
                          InkWell(
                            onTap: (){
                              AppContants.makePhoneCall(bookingResponse.senderContactNumber.toString());

                            },
                            child: Row(
                              children: [
                                Icon(Icons.call_outlined, color: Colors.blue, size: 16),
                                const SizedBox(width: 5),
                                Text('${bookingResponse.senderContactNumber} , ${bookingResponse.receiverName}'),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.location_on_outlined,color: Colors.red,),
                    const SizedBox(width: 15),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "${bookingResponse.dropAddress ?? ""}",
                            style: TextStyle(
                              color: TColor.primaryText,
                              fontSize: 15,
                            ),
                          ),
                          InkWell(
                            onTap: (){
                              AppContants.makePhoneCall(bookingResponse.receiverContactNumber.toString());

                            },
                            child: Row(
                              children: [
                                Icon(Icons.call_outlined, color: Colors.blue, size: 16),
                                const SizedBox(width: 5),
                                Text('${bookingResponse.receiverContactNumber} , ${bookingResponse.receiverName}'),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 25),
              bookingResponse.orderStatus.toString().toLowerCase() == "delivered" && bookingResponse.paymentStatus.toString().toLowerCase() == "pending"  ?

              Column(
                children: [
                  Text("Collect Payment",style: TextStyle(fontSize: 16,color: TColor.primary,fontWeight: FontWeight.bold),),
                  SizedBox(height: 10,),

                       InkWell(
                          onTap: () {
                            //   Navigator.pop(context);

                            orderPayment(bookingResponse.id.toString(),bookingResponse.driverId.toString(),generate8DigitKey().toString());
                          },
                          child: Container(
                            height: 40,


                            margin: const EdgeInsets.symmetric(horizontal: 15),
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                                color: TColor.red,
                                borderRadius: BorderRadius.circular(30)

                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [

                                Text(
                                  "Cash Collect",
                                  style: TextStyle(
                                    color: TColor.primaryTextW,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),



                ],
              ):

              Row(
                children: [
                  InkWell(
                    onTap: () {
                   //   Navigator.pop(context);
                      if(bookingResponse.orderStatus.toString().toLowerCase() == "picked"){
                        openGoogleMap(double.parse(bookingResponse.dropLat.toString()), double.parse(bookingResponse.dropLong.toString()));
                      }
                      else {
                        openGoogleMap(double.parse(bookingResponse.pickupLat.toString()), double.parse(bookingResponse.pickupLong.toString()));
                      }

                    },
                    child: Container(
                      width: 200,

                      margin: const EdgeInsets.only(left: 20),
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: TColor.red,
                        borderRadius: BorderRadius.circular(30)

                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.directions_outlined,color: Colors.white,),
                          SizedBox(width: 10,),
                          Text(
                            "Direction",
                            style: TextStyle(
                              color: TColor.primaryTextW,
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: InkWell(
                      onTap: () {

                        Navigator.pop(context);
                        if(bookingResponse.orderStatus.toString().toLowerCase() == "picked" ){

                          orderDelivered(orderID:bookingResponse.id.toString());

                        //  startTrip(bookingResponse.id.toString(), "no",context,bookingResponse.cusId.toString(),bookingResponse.orderId.toString(),bookingResponse.amount.toString());


                        }
                        else if (bookingResponse.orderStatus.toString().toLowerCase() == "accpeted"){
                          orderPicked(orderID:bookingResponse.id.toString());
                         // startTrip(bookingResponse.id.toString(), "yes",context,bookingResponse.cusId.toString(),bookingResponse.orderId.toString(),bookingResponse.amount.toString());
                        }

                      },
                      child: Container(
                        width: 100,
                        height: 40,
                        margin: const EdgeInsets.symmetric(horizontal: 20),
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: TColor.primary,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Stack(
                          alignment: Alignment.centerRight,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  bookingResponse.orderStatus.toString().contains("picked")  ? "Completed":"Start Trip",
                                  style: TextStyle(
                                    color: TColor.primaryTextW,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),

                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 25),
            ],
          ),
        ),
      ],
    );
  }


  String generate8DigitKey() {
    final random = Random();
    return (10000000 + random.nextInt(90000000)).toString();
  }

  Future<void>orderPayment(String id,String driverID,String key)
  async {

    isVehicle = true;

    update();
    print(getUserDeviceID());
    subCategoryVehicle = null;



    Response response = await authRepo.orderPayment(id: id,driverID: driverID,key: key);

    //  LoginResponse? loginResponse;

    if(response.statusCode==200 || response.statusCode ==400)
    {
      Get.offAll(HomeView());

      // subCategoryVehicle = SubCategoryVehicle.fromJson(response.body);
      //
      // isVehicle = false;
      update();
    }
    else {


      // dynamic data = jsonDecode(response.body);

      ApiChecker.checkApi(response);




    }

    isVehicle = false;
    update();



  }
  Future<void> openGoogleMap(double latitude, double longitude) async {
    final Uri googleMapUrl = Uri.parse("https://www.google.com/maps/search/?api=1&query=$latitude,$longitude");

    if (await canLaunchUrl(googleMapUrl)) {
      await launchUrl(googleMapUrl, mode: LaunchMode.externalApplication);
    } else {
      throw 'Google Maps नहीं खुल पाया!';
    }
  }

  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const R = 6371.0; // Earth's radius in kilometers

    // Convert degrees to radians
    double dLat = _toRadians(lat2 - lat1);
    double dLon = _toRadians(lon2 - lon1);

    // Apply Haversine formula
    double a = sin(dLat / 2) * sin(dLat / 2) +
        cos(_toRadians(lat1)) * cos(_toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2);

    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    double distance = R * c; // Distance in kilometers

    return distance;
  }

  double _toRadians(double degree) {
    return degree * (pi / 180);
  }



}